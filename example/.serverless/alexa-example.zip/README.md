# AlexaWorkshop

## Requirements
To use this skill
- Use alexa-skills-kit-nodejs-factskill form serverless repo to biuld CloudFormation Stack and then just paste source code
- Change bucket name in audio paths to your bucket name 
- Every object in bucket must be public
- Lambda needs write permissions to DynamoDB table
- Change table name
- Create your skill using JSON Editor in alexa developer console
